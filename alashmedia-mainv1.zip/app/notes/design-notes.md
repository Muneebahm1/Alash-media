## Design Tokens
-root background color: #F5F5F5 #F1F2F1
-Primary Color: #068509  (logo,hover text, button text, links,image border)
-Secondary Color: #0F5813  (footer background)
-Font Body: Custom next font

## UI Notes
-Button-Border-Radius: 12px
-font: inter
-font-size: 16px
-paragraph-spacing: 16px