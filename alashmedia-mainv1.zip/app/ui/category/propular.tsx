import React from 'react'

const propular = () => {
  return (
    <div>
        propular
    </div>
  )
}

export default propular