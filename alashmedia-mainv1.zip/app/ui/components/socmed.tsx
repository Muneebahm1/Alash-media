import React from 'react'

export const Socmed = () => {
  return (
    <div>Social Media</div>
  )
}

