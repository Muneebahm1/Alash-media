import React from 'react'

export const Alsoread = () => {
  return (
    <div>Alsoread</div>
  )
}
