//"SubHeader": {
    //    "NavLinks": {
    //        "informational": "معلوماتی",
    //        "educational": "تعلیمی",
    //        "biography": "سیرت",
    //        "alash": "الاش",
    //        "media": "میڈیا",
    //        "special project": "خصوصی پروجیکٹ"
    //    }
        
    //}