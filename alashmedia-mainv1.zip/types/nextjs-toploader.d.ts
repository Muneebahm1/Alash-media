declare module 'nextjs-toploader' {
  import { ComponentType } from 'react';
  const NextTopLoader: ComponentType<any>;
  export default NextTopLoader;
}
